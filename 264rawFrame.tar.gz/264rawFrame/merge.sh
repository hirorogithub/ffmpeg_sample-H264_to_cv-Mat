import os
os.system("cd ~/hiro/ibotn/server/ws_streaming_server_java/264rawFrame")
for i in range(1,197):
   os.system("cat outputFrame"+str(i)+" >> movie") 

